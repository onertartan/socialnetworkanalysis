/**
 * 
 */
package graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;

import util.GraphLoader;

/**
 * @author Your name here.
 * 
 *         For the warm up assignment, you must implement your Graph in a class
 *         named CapGraph. Here is the stub file.
 *
 */
public class CapGraph implements Graph {

	HashMap<Integer, HashSet<Integer>> nodeMap = new HashMap<Integer, HashSet<Integer>>();
	HashMap<Integer, HashSet<Integer>> transposedNodeMap = new HashMap<Integer, HashSet<Integer>>();
	Stack<Integer> vertices = new Stack<Integer>();

	@Override
	public void addVertex(int num) {
		if (!nodeMap.containsKey(num))
			nodeMap.put(num, new HashSet<Integer>());
		vertices.add(num);
	}

	@Override
	public void addEdge(int from, int to) {
		nodeMap.get(from).add(to);
	}

	private void addVertexWithEdges(int v, HashSet<Integer> edges) {
		nodeMap.put(v, edges);
	}

	@Override
	public Graph getEgonet(int center) {
		Graph g = new CapGraph();
		HashSet<Integer> neighbors = nodeMap.get(center);

		for (int n : neighbors) {
			g.addVertex(n);
			for (int j : nodeMap.get(n))
				if (neighbors.contains(j))
					g.addEdge(n, j);
		}
		return g;
	}

	public void getRecommendations(int v, int numOfRecommendations) {
		if (!nodeMap.containsKey(v)) {
			System.out.println("User not found");
			return;
		}
		HashSet<Integer> neighbors = nodeMap.get(v);
		HashMap<Integer, Integer> recomHashMap = new HashMap<Integer, Integer>();
		for (int neighbor : neighbors) {
			for (int neighbor2 : nodeMap.get(neighbor)) {
				if (!neighbors.contains(neighbor2) && neighbor2!=v) {
					if (!recomHashMap.containsKey(neighbor2))
						recomHashMap.put(neighbor2, 1);
					else
						recomHashMap.put(neighbor2, recomHashMap.get(neighbor2) + 1);
				}

			}
		}
		sortedRecommendations(recomHashMap, numOfRecommendations);
	}

	public void sortedRecommendations(HashMap<Integer, Integer> recomHashMap, int numOfRecommendations) {
		Comparator<Entry<Integer, Integer>> valueComparator = new Comparator<Entry<Integer, Integer>>() {

			@Override
			public int compare(Entry<Integer, Integer> e1, Entry<Integer, Integer> e2) {
				return -e1.getValue().compareTo(e2.getValue());
			}
		};

		Set<Entry<Integer, Integer>> entries = recomHashMap.entrySet();
		List<Entry<Integer, Integer>> listOfEntries = new ArrayList<Entry<Integer, Integer>>(entries);

		// sorting HashMap by values using comparator
		Collections.sort(listOfEntries, valueComparator);

		LinkedHashMap<Integer, Integer> recomLinkedHashMap = new LinkedHashMap<Integer, Integer>(listOfEntries.size());

		// copying entries from List to LinkedHashMap
		for (Entry<Integer, Integer> entry : listOfEntries) {
			recomLinkedHashMap.put(entry.getKey(), entry.getValue());
		}
		int counter = 0;
		if(numOfRecommendations<recomLinkedHashMap.size())
			System.out.println("FOUND "+recomLinkedHashMap.size());
		for (int recom : recomLinkedHashMap.keySet()) {
			if (counter < numOfRecommendations) {
				System.out.println(
						"Recommended user: " + recom + " Number of common friends: " + recomLinkedHashMap.get(recom));
				counter++;
			}
		}
	}

	@Override
	public List<Graph> getSCCs() {
		List<Graph> SCCs = new ArrayList<Graph>();

		Stack<Integer> finished = dfs(vertices,nodeMap,SCCs,false);
		transpose();
		dfs(finished,transposedNodeMap,SCCs,true);
		//dfs2(finished);
		return SCCs;
	}

	private HashMap<Integer, HashSet<Integer>> transpose() {

		for (int from : nodeMap.keySet()) {
			if (!transposedNodeMap.containsKey(from))
				transposedNodeMap.put(from, new HashSet<Integer>());

			for (int to : nodeMap.get(from)) {
				if (!transposedNodeMap.containsKey(to))
					transposedNodeMap.put(to, new HashSet<Integer>());

				transposedNodeMap.get(to).add(from);
			}
		}
		return transposedNodeMap;
	}
	
	private Stack<Integer> dfs(Stack<Integer> vertices,HashMap<Integer, HashSet<Integer>> nodeMap,	List<Graph> SCCs,boolean secondPass ) {
		Stack<Integer> finished = new Stack<Integer>();
		HashSet<Integer> visited = new HashSet<Integer>();

		int v;
		while (!vertices.isEmpty()) {
			v = vertices.pop();
			if (!visited.contains(v)) {
				visit(v, vertices, finished, visited,nodeMap);
				if(secondPass) {
					System.out.println("tempFinish " + finished);
					generateGraph(SCCs, finished);
					finished.clear();
				}
			}
			
		}
		return finished;
	}

	private List<Graph> dfs2(Stack<Integer> vertices) {
		List<Graph> SCCs = new ArrayList<Graph>();
		Stack<Integer> tempFinish = new Stack<Integer>();// tempFinish reset for every SCC
		HashSet<Integer> visited = new HashSet<Integer>();

		int v;
		while (!vertices.isEmpty()) {
			v = vertices.pop();

			if (!visited.contains(v)) {
				visit(v, vertices, tempFinish, visited,transposedNodeMap);
				System.out.println("tempFinish " + tempFinish);
				generateGraph(SCCs, tempFinish);
				tempFinish.clear();
				
				
			}
		}

		return SCCs;
	}

	private void visit(int v, Stack<Integer> vertices, Stack<Integer> finished, HashSet<Integer> visited,HashMap<Integer,HashSet<Integer>> nodeMap) {
		visited.add(v);
		for (int n : nodeMap.get(v)) {
			if (!visited.contains(n))
				visit(n, vertices, finished, visited,nodeMap);
		}
		finished.push(v);
	}

	private void generateGraph(List<Graph> SCCs, Stack<Integer> finished) {
		CapGraph g = new CapGraph();
		for (int v : finished)
			g.addVertexWithEdges(v, transposedNodeMap.get(v));
		SCCs.add(g);
	}

	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		return nodeMap;
	}

	public static void main(String[] args) {
		CapGraph myGraph = new CapGraph();
		GraphLoader.loadGraph(myGraph, "data/scc/myTest.txt");
		//myGraph.getRecommendations(8, 3);
		myGraph.getSCCs();

	}
}
