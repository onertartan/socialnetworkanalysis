package graph;

public class GraphEdge  {
	int from;
	int to;

	public GraphEdge(int from, int to) {
		super();
		this.from = from;
		this.to = to;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + from*to+from+to;
		result = prime * result + to*from+from+to;
         return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GraphEdge other = (GraphEdge) obj;
		if ( (from==other.from && to==other.to) || (from==other.to && to==other.from))
			return true;
		return false;
	}
	

	@Override
	public String toString() {
		return "GraphEdge: from=" + from + ", to=" + to  ;
	}

}
